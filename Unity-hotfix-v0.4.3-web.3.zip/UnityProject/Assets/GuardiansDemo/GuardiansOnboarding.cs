using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Nanyang;
using UnityEngine;

namespace JinShi
{
    /// <summary>
    /// 入职第一天: the data-centre red-line course as a short walk through 狮城一号石殿. The course is authored in
    /// Resources/Guardians/Onboarding.json (stages → steps); this file runs it: who stands where, what each step asks,
    /// which of the twenty red lines a choice proves or breaks, and the save.
    /// </summary>
    public sealed partial class GuardiansGame
    {
        OnbData data;GuardianSave progress;
        bool campaignReady,begun,testing,fading,stepActive;string menu="title",traineeName="";
        // dialogue
        string talker="";string[] lines,lineSpeakers;int line;Action afterTalk;List<(string label,Action run)> answers;
        // feedback card after a decision
        string cardText="";bool cardGood;int[] cardRules;Action cardThen;
        // sheets: slots / readback / sequence / results / certificate
        string board="",boardFeedback="";int[] picks;
        List<string> deck;int seqDone;float seqUntil;readonly HashSet<string> seqSpent=new HashSet<string>();
        float stageCardAt=-99,fadeAlpha;Vector2 scroll;
        readonly Dictionary<string,ActorView> people=new Dictionary<string,ActorView>();
        readonly List<GameObject> spawned=new List<GameObject>();
        readonly Dictionary<ActorView,(Vector3 to,ExplorationRoute route)> walkers=new Dictionary<ActorView,(Vector3,ExplorationRoute)>();
        readonly ExplorationRoute companionRoute=new ExplorationRoute();
        Rect cageRect;bool hasCage;float runClock;
        string pending="";AudioSource score,fx,siren;

        OnbStage Stage=>data.stages[Mathf.Clamp(progress.stage,0,data.stages.Length-1)];
        OnbStep Step=>Stage.steps[Mathf.Clamp(progress.step,0,Stage.steps.Length-1)];
        bool StageCard=>Time.unscaledTime-stageCardAt<2.6f;
        bool InModal=>streamGate||menu!=""||lines!=null||answers!=null||board!=""||cardText!=""||liftMenu||openInfo!=null||fading||StageCard||intro;
        static readonly int[] None=new int[0];
        static int[] R(int[] r)=>r??None;

        // ------------------------------------------------------------------ start / travel
        void CampaignStart()
        {
            data=JsonUtility.FromJson<OnbData>(Resources.Load<TextAsset>("Guardians/Onboarding").text);
            testing=Environment.GetCommandLineArgs().Contains("-guardians-check")||AndroidTestIntent()||AndroidTestIntent("guardians_render_check");
#if UNITY_ANDROID && !UNITY_EDITOR
            if(testing)GuardianWeb.SetEnglish(AndroidTestIntent("guardians_english"));
#endif
            GuardianStorage.Testing=GuardianWeb.Review||testing||Environment.GetCommandLineArgs().Contains("-guardians-manual")||AndroidTestIntent("guardians_manual");Application.runInBackground=GuardianStorage.Testing;
            progress=GuardianStorage.Read()??GuardianSave.Fresh(GuardianWeb.InitialName);traineeName=!string.IsNullOrWhiteSpace(GuardianWeb.InitialName)?GuardianWeb.InitialName:progress.name=="李毅"?"":progress.name;mapMenu=false;campaignReady=true;
            score=gameObject.AddComponent<AudioSource>();score.loop=true;score.volume=progress.music;score.spatialBlend=0;
            fx=gameObject.AddComponent<AudioSource>();fx.spatialBlend=0;fx.volume=progress.sound;
            siren=gameObject.AddComponent<AudioSource>();siren.loop=true;siren.spatialBlend=0;siren.clip=SirenClip();
            gameObject.name="EZSVSGame";GuardianWeb.Ready();
            score.clip=Resources.Load<AudioClip>("Music/home");if(score.clip!=null)score.Play();
            // the title screen sits over the forecourt
            Travel(data.stages[0].place,new Vector3(data.stages[0].spawnX,0,data.stages[0].spawnZ));
            if(Environment.GetCommandLineArgs().Contains("-guardians-interaction-check")||Environment.GetCommandLineArgs().Contains("-guardians-close-e"))StartCoroutine(InteractionReview(Environment.GetCommandLineArgs().Contains("-guardians-close-e")));
            else if(Environment.GetCommandLineArgs().Contains("-guardians-environment-check")||Environment.GetCommandLineArgs().Contains("-guardians-environment-manual"))StartCoroutine(EnvironmentReview(Environment.GetCommandLineArgs().Contains("-guardians-environment-manual")));
            else if(testing)StartCoroutine(CampaignCheck());
            else if(GuardianWeb.QA){testing=true;GuardianStorage.Testing=true;StartCoroutine(CampaignCheck());}
            else if(Environment.GetCommandLineArgs().Contains("-guardians-beauty")){GuardianStorage.Testing=true;StartCoroutine(BeautyShots());}
            else if(Environment.GetCommandLineArgs().Contains("-guardians-portraits")){GuardianStorage.Testing=true;StartCoroutine(PortraitShots());}
        }
        bool AndroidTestIntent(string key="guardians_check")
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using(var player=new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using(var activity=player.GetStatic<AndroidJavaObject>("currentActivity"))
            using(var intent=activity.Call<AndroidJavaObject>("getIntent"))
                return intent.Call<bool>("getBooleanExtra",key,false);
#else
            return false;
#endif
        }
        void Begin(bool resume)
        {
            var saved=resume?GuardianStorage.Read():null;
            progress=saved!=null&&!saved.finished?saved:GuardianSave.Fresh(traineeName);
            if(score!=null)score.volume=progress.music;
            begun=true;menu="";ClearModal();
            StartCoroutine(EnterStage(saved!=null&&!saved.finished));
        }
        void ClearModal(){lines=null;answers=null;afterTalk=null;lineSpeakers=null;cardText="";cardThen=null;board="";boardFeedback="";pending="";}
        void Travel(string id,Vector3? pos=null)
        {
            var s=GuardiansSites.All.FirstOrDefault(x=>x.places.Any(p=>p.id==id))??GuardiansSites.All[0];
            var p=s.places.FirstOrDefault(x=>x.id==id)??s.places[0];pending="";Load(s,p,pos);progress.place=p.id;
        }
        IEnumerator Fade(float to,float seconds)
        {
            if(testing){fadeAlpha=to;yield break;}
            float from=fadeAlpha;for(float t=0;t<seconds;t+=Time.unscaledDeltaTime){fadeAlpha=Mathf.Lerp(from,to,t/seconds);yield return null;}fadeAlpha=to;
        }
        /// <summary>Fade to black, move to the stage's place and mark, show the stage title, then start the current step.</summary>
        IEnumerator EnterStage(bool resume=false)
        {
            fading=true;lead.StopWalking();yield return Fade(1,.45f);
            var st=Stage;bool here=resume&&progress.place==st.place;
            var at=here?new Vector3(progress.x,0,progress.z):new Vector3(st.spawnX,0,st.spawnZ);
            // Earlier builds let players save beyond the lobby gate. Keep their
            // question progress and resume unfinished access training at the entrance.
            if(here&&st.id=="access"&&at.z> -12.5f)
                at=new Vector3(st.spawnX,0,st.spawnZ);
            yield return RequirePlace(st.place);
            Travel(st.place,at);lead.transform.rotation=Quaternion.Euler(0,st.spawnYaw,0);yaw=st.spawnYaw;pitch=18;SnapCamera();
            if(!testing)yield return new WaitForSecondsRealtime(.15f);
            fading=false;
            bool opening=!resume&&progress.stage==0&&progress.step==0&&!testing;
            if(opening)StartCoroutine(Intro());else if(progress.step==0&&!testing)stageCardAt=Time.unscaledTime;
            BeginStep();yield return Fade(0,opening?1.4f:.6f);
        }
        bool intro,introSkip;float introAt;const float IntroLength=8f;
        /// <summary>Opening: a crane from above the street down to the trainee walking up to the main entrance, title over it.</summary>
        IEnumerator Intro()
        {
            intro=true;introSkip=false;introAt=Time.unscaledTime;
            var goal=current.nav.SafePoint(new Vector3(Stage.spawnX,0,Stage.spawnZ+3.4f));var walk=new ExplorationRoute();
            while(Time.unscaledTime-introAt<IntroLength&&!introSkip)
            {
                lead.Move(walk.Next(current.nav,lead.transform.position,goal,.05f),GuardianLocomotion.WalkPace);yield return null;
            }
            lead.StopWalking();destination=lead.transform.position;route.Reset();
            yaw=lead.transform.eulerAngles.y;pitch=18;SnapCamera();intro=false;
        }
        void CampaignLoaded(){if(begun||menu=="title")SyncStage();}

        // ------------------------------------------------------------------ cast and props of the current stage
        void SyncStage()
        {
            var dead=new HashSet<GameObject>(spawned);spawned.Clear();walkers.Clear();hasCage=false;
            foreach(var g in dead)if(g!=null){g.SetActive(false);Destroy(g);}
            people.Clear();
            foreach(var a in current.root.GetComponentsInChildren<ActorView>(true))
            {
                if(dead.Contains(a.gameObject))continue;
                string id=a.actorId.StartsWith("npc_")?a.actorId.Substring(4):a.actorId;
                // the protagonist's model also stands in as a nameless extra in Codex's floors; never show a second 李毅
                if(id=="liyi"){a.gameObject.SetActive(false);continue;}
                if(!people.ContainsKey(id))people[id]=a;
            }
            PolishCast(lead);
            var st=Stage;if(st.place!=place.id||!begun&&menu!="title"){foreach(var a in people.Values)PolishCast(a);return;}
            foreach(var a in st.actors??new OnbActor[0])EnsureActor(a);
            foreach(var a in people.Values)PolishCast(a);
            if(st.props!=null&&st.props.Length>0)
            {
                foreach(var p in st.props){var g=BuildProp(p);if(g!=null)spawned.Add(g);}
                // props are solid: rebuild this place's walkable grid with them in it
                var watch=System.Diagnostics.Stopwatch.StartNew();
                current.nav=new ExplorationNavigation(current.root.transform,place.bounds);lead.navigation=current.nav;
                current.nav.AgentClear=GuardianBodyMotion.PathClear;
                foreach(var a in people.Values)if(a.relaxed)a.navigation=current.nav;
                Debug.Log($"GUARDIAN_NAV_REBUILT {place.id} obstacles={current.nav.ObstacleCount} ms={watch.ElapsedMilliseconds}");
            }
            foreach(var hz in HazardStep()?.hazards??new OnbHazard[0])if(progress.found.Contains(hz.id))Resolve(hz,true);
        }
        void EnsureActor(OnbActor a)
        {
            if(!people.TryGetValue(a.id,out var view))
            {
                var src=CastPrefab(a.model);bool cast=src!=null;if(!cast)src=Resources.Load<GameObject>("Actors/"+a.model);
                if(src==null){Debug.LogError("GUARDIAN_ACTOR_MISSING "+a.model);return;}
                view=Instantiate(src,current.root.transform).GetComponent<ActorView>();view.actorId="npc_"+a.id;view.civilian=true;
                if(!cast)Outfit(view,a.shirt??"#26354F",a.pants??"#2E3136");
                people[a.id]=view;spawned.Add(view.gameObject);
            }
            view.name=a.name??Who(a.id);view.gameObject.SetActive(true);view.relaxed=true;view.navigation=current.nav;
            GuardianBodyMotion.Ensure(view);
            view.transform.position=current.nav.SafePoint(new Vector3(a.x,0,a.z));view.transform.rotation=Quaternion.Euler(0,a.yaw,0);view.StopWalking();
            var pose=view.GetComponent<GuardianPose>();
            if(a.act=="phone"||a.act=="touch")
            {
                if(pose==null)pose=view.gameObject.AddComponent<GuardianPose>();pose.pose=a.act;
                if(a.act=="phone"&&pose.prop==null)pose.prop=Phone(view.transform);
            }
            else if(pose!=null)pose.pose="";
        }
        Transform Phone(Transform owner)
        {
            var g=new GameObject("手机");g.transform.SetParent(owner,false);
            Box(g.transform,Vector3.zero,new Vector3(.074f,.152f,.009f),JinShiKit.Lit("#1B1D20",.75f,.6f),0,false);
            Box(g.transform,new Vector3(0,0,-.005f),new Vector3(.066f,.138f,.001f),JinShiKit.Lit("#9FC6FF",.9f,0,1.4f),0,false);
            Box(g.transform,new Vector3(.022f,.058f,.005f),new Vector3(.014f,.014f,.002f),JinShiKit.Lit("#0D0E10",.9f,.3f),0,false);
            return g.transform;
        }
        static GameObject Box(Transform parent,Vector3 local,Vector3 size,Material m,float yaw=0,bool solid=true,PrimitiveType shape=PrimitiveType.Cube)
        {
            var g=GameObject.CreatePrimitive(shape);g.transform.SetParent(parent,false);g.transform.localPosition=local;g.transform.localRotation=Quaternion.Euler(0,yaw,0);g.transform.localScale=size;
            g.GetComponent<Renderer>().sharedMaterial=m;var c=g.GetComponent<Collider>();if(!solid)Destroy(c);else if(shape!=PrimitiveType.Cube){Destroy(c);g.AddComponent<BoxCollider>();}
            return g;
        }
        GameObject BuildProp(OnbProp p)
        {
            var root=new GameObject("场景道具 · "+p.id).transform;root.SetParent(current.root.transform,false);root.localPosition=new Vector3(p.x,p.y,p.z);root.localRotation=Quaternion.Euler(0,p.yaw,0);
            var rnd=new System.Random(p.id.GetHashCode());float J(float a)=>(float)(rnd.NextDouble()*2-1)*a;
            Material Kraft(float shade)=>JinShiKit.Lit(shade>.5f?"#B8925E":"#A9824F",.12f);var tape=JinShiKit.Lit("#C9B48A",.5f);
            void Carton(Vector3 at,float w,float h,float d,float yaw)
            {var b=Box(root,at+Vector3.up*h/2,new Vector3(w,h,d),Kraft((float)rnd.NextDouble()),yaw);Box(b.transform,new Vector3(0,.501f,0),new Vector3(1.002f,.004f,.16f),tape,0,false);}
            switch(p.kind)
            {
                case "kit":JinShiKit.Place(p.asset,root,Vector3.zero,0,p.label);break;
                // wall sign facing along the prop's yaw (same convention as Ctx.Sign: the text looks back along its normal)
                case "sign":{var t=JinShiKit.Label(root,p.label,Vector3.zero,0,.045f,new Color(.12f,.2f,.35f));t.transform.rotation=Quaternion.LookRotation(-(Quaternion.Euler(0,p.yaw,0)*Vector3.forward));break;}
                case "lockers":
                {
                    // staff locker bank, two tiers: powder-coated steel, louvred doors, number plates, cam locks; front faces local +z
                    var carcass=JinShiKit.Lit("#AEB4BA",.42f,.5f);var door=JinShiKit.Lit("#C6CCD2",.52f,.5f);var slot=JinShiKit.Lit("#24272B",.3f);var steelLock=JinShiKit.Lit("#8E959B",.75f,.9f);
                    int n=Mathf.Max(1,p.count);float w=.4f,depth=.5f,h=1.86f,len=n*w;
                    Box(root,new Vector3(0,h/2,0),new Vector3(len,h,depth),carcass);
                    Box(root,new Vector3(0,.05f,.015f),new Vector3(len-.01f,.1f,depth-.02f),JinShiKit.Lit("#3A3F45",.3f),0,false);
                    for(int i=0;i<n;i++)for(int tier=0;tier<2;tier++)
                    {
                        float x=-len/2+w*(i+.5f),y0=.13f+tier*.87f,dh=.83f,face=depth/2+.006f;
                        Box(root,new Vector3(x,y0+dh/2,face),new Vector3(w-.014f,dh,.012f),door,0,false);
                        for(int v=0;v<4;v++)Box(root,new Vector3(x,y0+dh-.1f-v*.032f,face+.007f),new Vector3(w*.56f,.011f,.002f),slot,0,false);
                        Box(root,new Vector3(x+w*.31f,y0+dh*.52f,face+.009f),new Vector3(.024f,.058f,.008f),steelLock,0,false);
                        Box(root,new Vector3(x,y0+dh-.045f,face+.007f),new Vector3(.07f,.032f,.002f),JinShiKit.Lit("#F2F2EE",.4f),0,false);
                        JinShiKit.Label(root,(i*2+tier+1).ToString("00"),new Vector3(x,y0+dh-.045f,face+.009f),180,.011f,new Color(.12f,.14f,.18f));
                    }
                    break;
                }
                case "exit":{var e=JinShiKit.Place("JS_ExitSign",root,Vector3.zero,0);if(e==null)JinShiKit.Label(root,"安全出口  EXIT",Vector3.zero,0,.06f,new Color(.1f,.7f,.3f));break;}
                case "cartons":
                    for(int i=0;i<Mathf.Max(1,p.count);i++)
                    {
                        int layer=i<3?0:i<5?1:2;int k=layer==0?i:layer==1?i-3:0;float z=layer==0?(k-1)*.68f:layer==1?(k-.5f)*.66f:0;
                        Carton(new Vector3(J(.08f),layer*.47f,z+J(.05f)),.6f,.46f,.56f,J(9));
                    }
                    break;
                case "mess":
                    Box(root,new Vector3(0,.012f,0),new Vector3(.92f,.018f,.66f),Kraft(.7f),14);Box(root,new Vector3(.75f,.03f,.45f),new Vector3(.86f,.018f,.6f),Kraft(.2f),-22);
                    Carton(new Vector3(-.7f,0,.5f),.48f,.36f,.42f,30);
                    for(int i=0;i<3;i++)Box(root,new Vector3(.2f+i*.38f,.07f,-.55f+J(.1f)),new Vector3(.42f,.13f,.28f),JinShiKit.Lit("#F1F1EE",.15f),J(40));
                    {var s=Box(root,new Vector3(-.3f,.02f,-.2f),new Vector3(.025f,.11f,.025f),JinShiKit.Lit("#D22B2B",.5f),0,false,PrimitiveType.Cylinder);s.transform.localRotation=Quaternion.Euler(90,35,0);}
                    for(int i=0;i<5;i++){var tie=Box(root,new Vector3(J(.6f),.004f,J(.6f)),new Vector3(.18f,.003f,.006f),JinShiKit.Lit("#E9E9E4",.3f),J(180),false);}
                    break;
                case "cart":
                {
                    var steel=JinShiKit.Lit("#8E959B",.55f,.8f);var deckMat=JinShiKit.Lit("#2C3034",.35f,.2f);
                    Box(root,new Vector3(0,.86f,0),new Vector3(.9f,.035f,.56f),deckMat);Box(root,new Vector3(0,.22f,0),new Vector3(.9f,.03f,.56f),deckMat,0,false);
                    foreach(var c in new[]{new Vector2(-.42f,-.25f),new Vector2(.42f,-.25f),new Vector2(-.42f,.25f),new Vector2(.42f,.25f)})
                    {Box(root,new Vector3(c.x,.48f,c.y),new Vector3(.025f,.84f,.025f),steel,0,false);Box(root,new Vector3(c.x,.05f,c.y),new Vector3(.06f,.1f,.06f),JinShiKit.Lit("#151617",.4f),0,false,PrimitiveType.Cylinder);}
                    Box(root,new Vector3(-.45f,1.02f,0),new Vector3(.025f,.025f,.56f),steel,0,false);
                    var cup=Box(root,new Vector3(.18f,.935f,.1f),new Vector3(.08f,.055f,.08f),JinShiKit.Lit("#F4F1EA",.25f),0,false,PrimitiveType.Cylinder);
                    Box(cup.transform,new Vector3(0,1.05f,0),new Vector3(1.04f,.12f,1.04f),JinShiKit.Lit("#3A2A20",.4f),0,false,PrimitiveType.Cylinder);
                    Box(cup.transform,new Vector3(0,.05f,0),new Vector3(1.01f,.34f,1.01f),JinShiKit.Lit("#8C5A3C",.3f),0,false,PrimitiveType.Cylinder);
                    var bottle=Box(root,new Vector3(.32f,.99f,-.12f),new Vector3(.066f,.11f,.066f),JinShiKit.Lit("#BFE3F5",.95f,0,0,.45f),0,false,PrimitiveType.Cylinder);
                    Box(bottle.transform,new Vector3(0,1.1f,0),new Vector3(.5f,.12f,.5f),JinShiKit.Lit("#2F6FD0",.5f),0,false,PrimitiveType.Cylinder);
                    Box(root,new Vector3(-.15f,.26f,0),new Vector3(.5f,.06f,.36f),JinShiKit.Lit("#3B6FB6",.4f),0,false);
                    break;
                }
                case "cage":
                {
                    var post=JinShiKit.Lit("#3A3F45",.45f,.6f);var mesh=JinShiKit.Lit("#2A2E33",.3f,.4f,0,.34f);float w=p.w,d=p.d,zc=d/2;
                    void Panel(Vector3 a,Vector3 b,bool solid)
                    {
                        var mid=(a+b)/2;float len=Vector3.Distance(a,b);float yawP=Mathf.Atan2(b.x-a.x,b.z-a.z)*Mathf.Rad2Deg;
                        Box(root,mid+Vector3.up*1.15f,new Vector3(.02f,2.2f,len),mesh,yawP,solid);Box(root,mid+Vector3.up*2.27f,new Vector3(.05f,.05f,len),post,yawP,false);
                        for(float s=0;s<=len+.01f;s+=1.25f){var q=Vector3.Lerp(a,b,s/len);Box(root,q+Vector3.up*1.2f,new Vector3(.05f,2.4f,.05f),post,0,false);}
                    }
                    Panel(new Vector3(0,0,0),new Vector3(w,0,0),true);Panel(new Vector3(w,0,0),new Vector3(w,0,d),true);Panel(new Vector3(w,0,d),new Vector3(0,0,d),true);
                    Panel(new Vector3(0,0,d),new Vector3(0,0,zc+.55f),true);Panel(new Vector3(0,0,zc-.55f),new Vector3(0,0,0),true);
                    // the gate is ajar: hinged at the south jamb, swung 24° out; no collider, so the gap stays walkable
                    var gate=new GameObject("笼门").transform;gate.SetParent(root,false);gate.localPosition=new Vector3(0,0,zc-.55f);gate.localRotation=Quaternion.Euler(0,-24,0);
                    Box(gate,new Vector3(0,1.15f,.55f),new Vector3(.02f,2.2f,1.1f),mesh,0,false);Box(gate,new Vector3(0,1.15f,1.08f),new Vector3(.04f,2.2f,.04f),post,0,false);
                    var plate=Box(gate,new Vector3(-.02f,1.55f,.55f),new Vector3(.01f,.3f,.7f),JinShiKit.Lit("#F2C21B",.4f),0,false);
                    var label=JinShiKit.Label(gate,p.label,new Vector3(-.03f,1.55f,.55f),0,.016f,new Color(.1f,.1f,.1f));label.transform.localRotation=Quaternion.LookRotation(Vector3.right);
                    for(int i=0;i<3;i++)JinShiKit.Place(i==1?"JS_Rack_Network":"JS_Rack_Server",root,new Vector3(2.4f+i*.6f,0,d*.62f),180,$"C-0{i+1}");
                    for(int i=0;i<3;i++)JinShiKit.Place("JS_Rack_ServerB",root,new Vector3(2.4f+i*.6f,0,d*.3f),0,$"C-1{i+1}");
                    cageRect=Rect.MinMaxRect(p.x+.15f,p.z+.15f,p.x+w-.15f,p.z+d-.15f);hasCage=true;
                    break;
                }
                case "puddle":
                {
                    var water=JinShiKit.Lit("#5E7F95",.98f,0,0,.55f);
                    for(int i=0;i<4;i++){var g=Box(root,new Vector3(J(p.w*.3f),.004f+i*.0005f,J(p.d*.25f)),new Vector3(p.w*(.5f+.15f*i),.0008f,p.d*(.45f+.12f*i)),water,J(30),false,PrimitiveType.Cylinder);}
                    break;
                }
                case "alarm":
                {
                    var lamp=Box(root,Vector3.zero,new Vector3(.16f,.1f,.16f),JinShiKit.Lit("#FF2A1A",.6f,0,2.5f),0,false,PrimitiveType.Cylinder);
                    var l=JinShiKit.PointLight(root,new Vector3(0,-.3f,0),9,2.2f,new Color(1,.18f,.1f));root.gameObject.AddComponent<AlarmPulse>().lamp=l;
                    break;
                }
            }
            return root.gameObject;
        }

        // ------------------------------------------------------------------ steps
        void BeginStep()
        {
            stepActive=false;boardFeedback="";var s=Step;
            if(s.x!=0||s.z!=0)if(people.TryGetValue(s.giver??"",out var giver))walkers[giver]=(current.nav.SafePoint(new Vector3(s.x,0,s.z)),new ExplorationRoute());
            if(Stage.id=="emergency")SetSiren(true);
            SaveProgress();
        }
        OnbStep HazardStep()=>Stage.steps.FirstOrDefault(s=>s.type=="hazards");
        bool IsPerson(string id)=>!string.IsNullOrEmpty(id)&&id!="auto"&&people.ContainsKey(id);
        Vector3? StepTarget()
        {
            var s=Step;if(s.type=="hazards"){var hz=OpenHazards().OrderBy(h=>Flat(HazardPos(h)-lead.transform.position)).FirstOrDefault();return hz!=null?HazardPos(hz):(Vector3?)null;}
            if(IsPerson(s.giver))return people[s.giver].transform.position;
            if(string.IsNullOrEmpty(s.giver))return new Vector3(s.x,0,s.z);return null;
        }
        IEnumerable<OnbHazard> OpenHazards()=>Step.type=="hazards"?Step.hazards.Where(h=>!progress.found.Contains(h.id)):Enumerable.Empty<OnbHazard>();
        Vector3 HazardPos(OnbHazard h)=>!string.IsNullOrEmpty(h.actor)&&people.TryGetValue(h.actor,out var a)?a.transform.position:new Vector3(h.x,0,h.z);
        void RunStep()
        {
            var s=Step;stepActive=true;
            // the leak: keep the water and the beacon in shot while the alarm, the trainee's choices and the radio play out
            var puddle=Stage.props?.FirstOrDefault(p=>p.kind=="puddle");if(puddle!=null)shotFocus=new Vector3(puddle.x,.35f,puddle.z);
            Action main=()=>
            {
                switch(s.type)
                {
                    case "talk":Advance();break;
                    case "choice":Ask(s);break;
                    case "slots":case "readback":board=s.type;picks=Enumerable.Repeat(-1,s.slots.Length).ToArray();boardFeedback="";scroll=Vector2.zero;break;
                    case "sequence":StartSequence();break;
                    case "results":board="results";scroll=Vector2.zero;break;
                    case "hazards":break;
                }
            };
            if(s.beats!=null&&s.beats.Length>0)Scene(s.beats,main);else main();
        }
        void Then(OnbStep s){if(s.after!=null&&s.after.Length>0)Scene(s.after,Advance);else Advance();}
        void Advance()
        {
            ClearModal();progress.step++;
            if(progress.step<Stage.steps.Length){BeginStep();return;}
            SetSiren(false);
            if(progress.stage+1>=data.stages.Length){progress.step=Stage.steps.Length-1;SaveProgress();return;}
            progress.stage++;progress.step=0;SaveProgress();StartCoroutine(EnterStage());
        }
        void Finish()
        {
            progress.finished=true;progress.completed=DateTime.Now.ToString("yyyy-MM-dd HH:mm");SaveProgress();ClearModal();begun=false;menu="title";
            Travel(data.stages[0].place,new Vector3(data.stages[0].spawnX,0,data.stages[0].spawnZ));
        }

        // ------------------------------------------------------------------ dialogue
        string DialogueSpeaker=>lineSpeakers!=null&&line<lineSpeakers.Length?lineSpeakers[line]:talker;
        void Scene(OnbBeat[] beats,Action after){Speak(beats[0].speaker,beats.Select(b=>b.text).ToArray(),after);lineSpeakers=beats.Select(b=>b.speaker).ToArray();}
        void Speak(string id,string[] text,Action after=null)
        {
            talker=id;lineSpeakers=null;lines=text;line=0;answers=null;afterTalk=after;pending="";destination=lead.transform.position;route.Reset();lead.StopWalking();
            if(people.TryGetValue(id,out var p))
            {
                // conversation distance: step back if the walk ended up nose to nose
                var gap=lead.transform.position-p.transform.position;gap.y=0;
                if(gap.magnitude<1.1f){var back=current.nav.SafePoint(p.transform.position+(gap.sqrMagnitude>.01f?gap.normalized:p.transform.forward)*1.3f);if(Flat(back-p.transform.position)>1f)lead.transform.position=back;}
                p.SnapFace(lead.transform.position);lead.SnapFace(p.transform.position);
                destination=lead.transform.position;route.Reset();
            }
        }
        void Choices(string id,string text,params (string label,Action run)[] options){talker=id;lineSpeakers=null;lines=new[]{text};line=0;afterTalk=null;answers=options.ToList();}
        void NextLine(){if(lines==null||answers!=null)return;if(line<lines.Length-1){line++;return;}var then=afterTalk;afterTalk=null;lines=null;lineSpeakers=null;then?.Invoke();}
        string Who(string id)
        {
            foreach(var st in data.stages)foreach(var a in st.actors??new OnbActor[0])if(a.id==id&&!string.IsNullOrEmpty(a.name))return a.name;
            return GuardianBook.Name(id);
        }
        string IdleLine(string id)=>id switch
        {
            "yuanyuting"=>"拿不准的时候先停下来问。问一句不丢人，越线才丢人。",
            "yandy"=>"我批的是 B 区。别的地方，门开着也不进。",
            "qin"=>"进出都要刷自己的卡。卡丢了先来前台。",
            "jay"=>"我是急性子。所以我更需要有人在旁边说一句「先核对」。",
            "teacherchen"=>"培训通过是起点，到了现场还要一条一条做对。",
            "faiz"=>"空调有点异响，我已经报给值班长了。我只看，不动手。",
            "xiaoman"=>"工具借出、归还都要登记。作业完，工具和现场一起收干净。",
            _=>"今天第一天？别着急，拿不准就先问。"
        };

        // ------------------------------------------------------------------ decisions
        void Ask(OnbStep s)=>Choices(IsPerson(s.giver)?s.giver:talker,s.question,s.options.Select(o=>(o.label,(Action)(()=>Answer(s,o)))).ToArray());
        void Answer(OnbStep s,OnbOption o)
        {
            lines=null;answers=null;
            if(o.correct){foreach(int r in R(s.rules))progress.Pass(r);Card(true,o.feedback,R(s.rules),()=>Then(s));}
            else
            {
                var rs=R(o.rules).Length>0?o.rules:R(s.rules);Mistake(s.question,o.label,o.feedback,rs);
                Card(false,o.feedback,rs,()=>Ask(s));
            }
        }
        void AskHazard(OnbHazard h)
        {
            stepActive=true;string who=!string.IsNullOrEmpty(Stage.companion)&&people.ContainsKey(Stage.companion)?Stage.companion:"record";
            Choices(who,h.title+"\n"+h.text+"\n你怎么处理？",h.options.Select(o=>(o.label,(Action)(()=>AnswerHazard(h,o)))).ToArray());
            if(!string.IsNullOrEmpty(h.actor)&&people.TryGetValue(h.actor,out var a))lead.SnapFace(a.transform.position);else lead.SnapFace(HazardPos(h));
            shotFocus=HazardPos(h)+Vector3.up*(string.IsNullOrEmpty(h.actor)?.7f:1.45f);
        }
        void AnswerHazard(OnbHazard h,OnbOption o)
        {
            lines=null;answers=null;var s=Step;
            if(!o.correct){var rs=R(o.rules).Length>0?o.rules:R(h.rules);Mistake(h.title,o.label,o.feedback,rs);Card(false,o.feedback,rs,()=>AskHazard(h));return;}
            foreach(int r in R(h.rules))progress.Pass(r);if(!progress.found.Contains(h.id))progress.found.Add(h.id);Resolve(h,false);SaveProgress();
            bool all=s.hazards.All(x=>progress.found.Contains(x.id));
            Card(true,o.feedback+"\n已记入巡检工单（"+s.hazards.Count(x=>progress.found.Contains(x.id))+" / "+s.hazards.Length+"）。",R(h.rules),()=>{shotFocus=null;if(all)Then(s);else stepActive=false;});
        }
        /// <summary>A handled hazard stops being a hazard: the runner walks, the phone goes down, the hand comes off the rack.</summary>
        void Resolve(OnbHazard h,bool instant)
        {
            if(string.IsNullOrEmpty(h.actor)||!people.TryGetValue(h.actor,out var a))return;
            var pose=a.GetComponent<GuardianPose>();if(pose!=null)pose.pose="";
            a.StopWalking();if(!instant)a.SnapFace(lead.transform.position);
        }
        void Mistake(string question,string choice,string feedback,int[] rules)
        {
            foreach(int r in rules)progress.Miss(r);progress.mistakes++;
            progress.log.Add($"【{Stage.title}】{question.Split('\n')[0]}\n你的选择：{choice}\n{feedback}\n"+string.Join("\n",rules.Select(r=>$"红线 {r}：{data.Rule(r)}")));
            SaveProgress();
        }
        void Card(bool good,string text,int[] rules,Action then){cardGood=good;cardText=string.IsNullOrEmpty(text)?(good?"做得对。":"不对。"):text;cardRules=rules;cardThen=then;Sound(good?"Cast":"Break");}
        void CloseCard(){var then=cardThen;cardThen=null;cardText="";then?.Invoke();}

        // ------------------------------------------------------------------ sheets
        void SubmitBoard()
        {
            var s=Step;var wrong=new List<string>();
            for(int i=0;i<s.slots.Length;i++)
            {
                var slot=s.slots[i];if(picks[i]==slot.correct)continue;
                wrong.Add("· "+slot.name+"：不是「"+(picks[i]>=0?slot.options[picks[i]]:"未选")+"」。"+slot.why);
                Mistake((s.panel??"").Split('\n')[0]+" · "+slot.name,picks[i]>=0?slot.options[picks[i]]:"未选",slot.why,R(slot.rules));
            }
            if(wrong.Count>0){boardFeedback="还有 "+wrong.Count+" 项不对：\n"+string.Join("\n",wrong);Sound("Break");return;}
            foreach(var slot in s.slots)foreach(int r in R(slot.rules))progress.Pass(r);foreach(int r in R(s.rules))progress.Pass(r);
            board="";Card(true,s.type=="readback"?"读回一致：设备、端口、变更单都对上了。复核人要逐项核对，不是在旁边看着。":(s.note??"都对了。"),R(s.rules),()=>Then(s));
        }
        void StartSequence()
        {
            var s=Step;var rnd=new System.Random(7);deck=s.sequence.Concat(s.distractors.Select(d=>d.label)).OrderBy(_=>rnd.Next()).ToList();
            seqDone=0;seqSpent.Clear();seqUntil=Time.unscaledTime+(s.timeLimit>0?s.timeLimit:60);board="sequence";boardFeedback="";SetSiren(true);
        }
        void PickSequence(string label)
        {
            var s=Step;if(board!="sequence"||seqSpent.Contains(label))return;
            if(label==s.sequence[seqDone])
            {
                seqSpent.Add(label);seqDone++;boardFeedback="✓ "+label;Sound("Cast");
                if(seqDone<s.sequence.Length)return;
                board="";SetSiren(false);foreach(int r in R(s.rules))progress.Pass(r);
                Card(true,"停止作业 → 确保人员安全并按应急流程上报 → 等待现场负责人指令。你没有自己去修，也没有瞒报。",R(s.rules),()=>Then(s));return;
            }
            var d=s.distractors.FirstOrDefault(x=>x.label==label);
            if(d!=null){seqSpent.Add(label);Mistake(s.question,label,d.feedback,R(d.rules));seqUntil-=5;boardFeedback="✗ "+d.feedback+"（-5 秒）";Sound("Break");return;}
            progress.mistakes++;progress.log.Add($"【{Stage.title}】处置顺序\n你先选了：{label}\n正确顺序：{string.Join(" → ",s.sequence)}");
            seqUntil-=3;boardFeedback="✗ 顺序不对：先停止作业，再确保人员安全，然后上报，最后等待指令。（-3 秒）";Sound("Break");
        }
        void SequenceTimeout()
        {
            var s=Step;board="";Mistake(s.question,"超时未完成","发现异味、漏水、告警，须立即上报，不能拖。",R(s.rules));
            Card(false,"时间到。发现异味、漏水、告警，要立刻停下、保证人员安全、马上上报。再来一次。",R(s.rules),StartSequence);
        }

        // ------------------------------------------------------------------ per-frame
        bool CampaignUpdate()
        {
            if(!campaignReady)return false;mapMenu=false;
            if(intro){if(Time.unscaledTime-introAt>.6f&&(Input.anyKeyDown||Input.touchCount>0))introSkip=true;return true;}
            UpdateActors();
            if(board=="sequence"&&cardText==""&&Time.unscaledTime>seqUntil)SequenceTimeout();
            if(Input.GetKeyDown(KeyCode.Escape))
            {
                if(openInfo!=null)openInfo=null;else if(menu=="handbook")menu="";else if(liftMenu)liftMenu=false;
                else if((board=="slots"||board=="readback")){board="";stepActive=false;}else if(begun&&!InModal)menu="handbook";return true;
            }
            if(begun&&Input.GetKeyDown(KeyCode.H)&&(menu==""||menu=="handbook")&&lines==null&&answers==null&&board==""&&cardText==""){menu=menu==""?"handbook":"";return true;}
            if(InModal||!begun)
            {
                lead.StopWalking();
                // E can also advance ordinary dialogue; never auto-select an answer.
                if(Input.GetKeyDown(KeyCode.E)&&lines!=null&&answers==null&&!fading&&!intro)NextLine();
                return true;
            }
            if(Input.GetKeyDown(KeyCode.E)){Interact();return true;}
            var s=Step;
            if(!stepActive&&s.giver=="auto"){RunStep();return true;}
            if(!stepActive&&string.IsNullOrEmpty(s.giver)&&s.type!="hazards"&&Flat(new Vector3(s.x,0,s.z)-lead.transform.position)<2.2f){RunStep();return true;}
            if(Input.GetKeyDown(KeyCode.G)){Guide();return true;}
            Watch();
            if(pending!="")
            {
                var target=TargetOf(pending);
                if(target.HasValue&&Flat(target.Value-lead.transform.position)<2.4f){string key=pending;pending="";destination=lead.transform.position;route.Reset();lead.StopWalking();Use(key);return true;}
                if(target.HasValue)destination=target.Value;
                else pending="";
            }
            if(Input.GetMouseButtonDown(0)&&PointerInHUD())return true;
            return false;
        }
        /// <summary>Red lines the player can break just by walking: running in the hall, stepping into the customer cage.</summary>
        void Watch()
        {
            bool inHall=place.id=="sg1_l2"&&lead.transform.position.x>-12&&lead.transform.position.z>-12;
            if(inHall&&lead.WalkSpeed>2.6f)runClock+=Time.deltaTime;else runClock=Mathf.Max(0,runClock-Time.deltaTime);
            if(runClock>.9f)
            {
                runClock=0;progress.runWarnings++;lead.StopWalking();destination=lead.transform.position;route.Reset();touchRun=false;
                if(progress.runWarnings==1)Card(false,"机房里不能跑。这次先提醒你：架空地板、线缆、设备旁边，跑一步都可能出事。再跑就记为越线。",new[]{10},null);
                else{Mistake("在机房内奔跑","奔跑","机房内禁止打闹、奔跑、睡觉或做与工作无关的事。",new[]{10});Card(false,"你在机房里奔跑。已记为越线。",new[]{10},null);}
            }
            if(hasCage&&place.id=="sg1_l2"&&cageRect.Contains(new Vector2(lead.transform.position.x,lead.transform.position.z)))
            {
                lead.transform.position=current.nav.SafePoint(new Vector3(cageRect.xMin-1.4f,0,cageRect.center.y));lead.StopWalking();destination=lead.transform.position;route.Reset();
                Mistake("走进客户 C 专区","进入","禁止进入未授权区域，包括其他客户机柜区、配电室和限制区域。门开着也不进。",new[]{3});
                Card(false,"你走进了另一家客户的专区。你的权限只有 B 区，门开着也不进。已记为越线。",new[]{3},null);
            }
        }
        void UpdateActors()
        {
            if(fading||people.Count==0)return;
            foreach(var kv in walkers.ToArray())
            {
                var a=kv.Key;if(a==null){walkers.Remove(a);continue;}if(GuardianBodyMotion.Ensure(a).IsYielding)continue;
                if(Flat(kv.Value.to-a.transform.position)<.25f){a.StopWalking();a.Face(lead.transform.position);walkers.Remove(a);continue;}
                a.Move(kv.Value.route.Next(current.nav,a.transform.position,kv.Value.to,.05f),GuardianLocomotion.WalkPace);
            }
            var st=Stage;if(st.place!=place.id)return;
            foreach(var act in (st.actors??new OnbActor[0]).Where(x=>x.act=="run"))
            {
                if(!people.TryGetValue(act.id,out var r))continue;if(GuardianBodyMotion.Ensure(r).IsYielding)continue;bool done=progress.found.Contains(act.id);
                if(done||InModal&&talker==act.id||Flat(lead.transform.position-r.transform.position)<3.2f){r.StopWalking();if(!done)r.Face(lead.transform.position,4);continue;}
                var a0=new Vector3(act.x,0,act.z);var b0=new Vector3(act.x2,0,act.z2);
                var goal=(Time.time/((b0-a0).magnitude/3.4f+1.2f))%2<1?b0:a0;r.Move(goal,3.4f);
            }
            // the companion keeps pace a couple of metres behind, never in the way of the step's own conversation
            if(!InModal&&!string.IsNullOrEmpty(st.companion)&&people.TryGetValue(st.companion,out var c)&&Step.giver!=st.companion&&!walkers.ContainsKey(c))
            {
                if(GuardianBodyMotion.Ensure(c).IsYielding)return;
                float d=Flat(lead.transform.position-c.transform.position);
                if(d>2.8f)c.Move(companionRoute.Next(current.nav,c.transform.position,lead.transform.position,1.8f),d>6?GuardianLocomotion.WalkPace*1.6f:GuardianLocomotion.WalkPace);
                else if(c.WalkSpeed>.01f){c.StopWalking();companionRoute.Reset();}
            }
        }
        Vector3? TargetOf(string key)
        {
            var hz=OpenHazards().FirstOrDefault(h=>h.id==key);if(hz!=null)return HazardPos(hz);
            if(people.TryGetValue(key,out var p))return p.transform.position;
            if(key=="#step"&&string.IsNullOrEmpty(Step.giver))return new Vector3(Step.x,0,Step.z);return null;
        }
        void Use(string key)
        {
            var hz=OpenHazards().FirstOrDefault(h=>h.id==key||h.actor==key);if(hz!=null){AskHazard(hz);return;}
            var s=Step;if(key==s.giver&&!stepActive){RunStep();return;}
            if(key=="#step"){if(!stepActive)RunStep();return;}
            if(people.ContainsKey(key))Speak(key,new[]{IdleLine(key)});
        }
        bool PointerInHUD(){var p=Input.mousePosition;return p.y>Screen.height-118*uiScale||InModal;}
        bool CampaignClick()
        {
            if(PointerInHUD())return true;string best="";float d=52;
            foreach(var hz in OpenHazards()){var p=cam.WorldToScreenPoint(HazardPos(hz)+Vector3.up*1.1f);float dd=Vector2.Distance(p,Input.mousePosition);if(p.z>0&&dd<d){d=dd;best=hz.id;}}
            foreach(var kv in people.Where(p=>p.Value.gameObject.activeInHierarchy)){var p=cam.WorldToScreenPoint(kv.Value.transform.position+Vector3.up*1.1f);float dd=Vector2.Distance(p,Input.mousePosition);if(p.z>0&&dd<d){d=dd;best=kv.Key;}}
            if(best=="")return false;GoTo(best);return true;
        }
        /// <summary>E: nearest person or open hazard within reach; otherwise doors, lift and equipment notes.</summary>
        bool CampaignInteract()
        {
            if(!begun)return true;
            string key=NearestKey(2.6f);if(key=="")return false;Use(key);return true;
        }
        string NearestKey(float reach)
        {
            string best="";float distance=reach;
            foreach(var hz in OpenHazards()){float d=Flat(HazardPos(hz)-lead.transform.position);if(d<distance){best=hz.id;distance=d;}}
            // whoever the current step is waiting on wins over a bystander standing about as close
            foreach(var kv in people.Where(p=>p.Value.gameObject.activeInHierarchy))
            {float d=Flat(kv.Value.transform.position-lead.transform.position)-(kv.Key==Step.giver&&!stepActive?.8f:0);if(d<distance-.3f){best=kv.Key;distance=d;}}
            return best;
        }
        void GoTo(string key)
        {
            pending=key;var target=TargetOf(key)??lead.transform.position;
            destination=target;keyboard=false;route.Reset();
        }
        int hintLevel;
        void Guide()
        {
            if(Stage.place!=place.id){StartCoroutine(EnterStage());return;}
            var s=Step;
            if(s.type=="hazards"&&hintLevel++%2==0){Notice("提示：看看出口和通道、地面、推车，还有身边人在做什么。还差 "+OpenHazards().Count()+" 处。");return;}
            if(s.type=="hazards"){var hz=OpenHazards().OrderBy(h=>Flat(HazardPos(h)-lead.transform.position)).FirstOrDefault();if(hz!=null)GoTo(hz.id);return;}
            if(IsPerson(s.giver))GoTo(s.giver);else if(string.IsNullOrEmpty(s.giver))GoTo("#step");
        }

        // ------------------------------------------------------------------ save and sound
        void SaveProgress(int slot=0)
        {
            if(!begun||progress==null)return;progress.place=place.id;progress.x=lead.transform.position.x;progress.z=lead.transform.position.z;
            try{GuardianStorage.Write(progress,slot);}catch(Exception e){Notice("存档未写入："+e.Message);Debug.LogError("GUARDIAN_SAVE "+e);}
        }
        void Sound(string name){if(fx!=null){fx.volume=progress.sound;var c=Resources.Load<AudioClip>("Audio/"+name);if(c!=null)fx.PlayOneShot(c);}}
        void SetSiren(bool on){if(siren==null)return;siren.volume=progress.sound*.35f;if(on&&!siren.isPlaying)siren.Play();else if(!on)siren.Stop();}
        static AudioClip SirenClip()
        {
            // two-tone facility alarm: 0.45 s at 880 Hz, 0.45 s at 660 Hz, soft attack so it does not click
            const int rate=22050;var samples=new float[rate*9/10];
            for(int i=0;i<samples.Length;i++){float t=i/(float)rate;float f=t<.45f?880:660;float env=Mathf.Clamp01(Mathf.Min(t%.45f,.45f-t%.45f)*40);samples[i]=Mathf.Sin(2*Mathf.PI*f*t)*.5f*env;}
            var clip=AudioClip.Create("警报",samples.Length,1,rate,false);clip.SetData(samples,0);return clip;
        }
        void OnApplicationFocus(bool focus){if(score!=null)score.mute=!focus;if(fx!=null)fx.mute=!focus;if(focus&&Application.isMobilePlatform)ApplyTabletFullscreen();}
        void OnApplicationPause(bool paused){if(paused){SaveProgress();if(score!=null)score.Pause();}else if(score!=null)score.UnPause();}
        void OnApplicationQuit(){SaveProgress();}
    }

    /// <summary>Rotating-beacon feel for the leak alarm: the red light breathes at 1.5 Hz.</summary>
    public sealed class AlarmPulse:MonoBehaviour
    {
        public Light lamp;float baseIntensity=-1;
        void Update(){if(lamp==null)return;if(baseIntensity<0)baseIntensity=lamp.intensity;lamp.intensity=baseIntensity*(.25f+.75f*Mathf.Abs(Mathf.Sin(Time.time*Mathf.PI*1.5f)));}
    }
}

