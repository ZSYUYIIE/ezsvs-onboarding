using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
namespace EZSVS.Editor {
public static class WebBuild {
 static UniversalRenderPipelineAsset Pipeline(bool tablet) {
  string key=tablet?"WebTablet":"WebDesktop",dir="Assets/Resources/Guardians/";
  if(!File.Exists(dir+key+"Renderer.asset"))AssetDatabase.CopyAsset("Assets/WebOriginalPipelines/MobileRenderer.asset",dir+key+"Renderer.asset");
  if(!File.Exists(dir+key+"URP.asset"))AssetDatabase.CopyAsset("Assets/WebOriginalPipelines/MobileURP.asset",dir+key+"URP.asset");
  var renderer=AssetDatabase.LoadAssetAtPath<UniversalRendererData>(dir+key+"Renderer.asset");
  var pipe=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(dir+key+"URP.asset");
  var ps=new SerializedObject(pipe);
  ps.FindProperty("m_RendererDataList").GetArrayElementAtIndex(0).objectReferenceValue=renderer;
  ps.FindProperty("m_SupportsHDR").boolValue=true;
  ps.FindProperty("m_RequireDepthTexture").boolValue=!tablet;
  ps.FindProperty("m_MSAA").intValue=1;
  ps.FindProperty("m_RenderScale").floatValue=1;
  ps.FindProperty("m_MainLightShadowmapResolution").intValue=tablet?1024:2048;
  ps.FindProperty("m_ShadowCascadeCount").intValue=2;
  ps.FindProperty("m_ShadowDistance").floatValue=tablet?10:24;
  ps.FindProperty("m_SoftShadowsSupported").boolValue=!tablet;
  ps.FindProperty("m_SoftShadowQuality").intValue=1;
  ps.FindProperty("m_AdditionalLightsPerObjectLimit").intValue=tablet?2:4;
  ps.FindProperty("m_UseSRPBatcher").boolValue=!tablet;
  ps.FindProperty("m_ReflectionProbeBoxProjection").boolValue=true;
  ps.FindProperty("m_ReflectionProbeBlending").boolValue=false;
  ps.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(pipe);return pipe;
 }
 public static void Build(){BuildDesktop();BuildMobile();}
 public static void BuildDesktop()=>BuildVariant(WebGLTextureSubtarget.DXT,"Builds/WebRaw","Builds/StreamedDesktop","desktop");
 public static void BuildMobile()=>BuildVariant(WebGLTextureSubtarget.ETC2,"Builds/WebMobileRaw","Builds/StreamedMobile","mobile");
 static void BuildVariant(WebGLTextureSubtarget textures,string output,string streams,string variant){
  if(!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.WebGL,BuildTarget.WebGL))
   throw new InvalidOperationException("Install matching Web Build Support and restart the Editor before building.");
  PlayerSettings.companyName="EZSVS";PlayerSettings.productName="EZSVS · 入职第一天";PlayerSettings.bundleVersion="0.4.3-web.2";
  PlayerSettings.SetScriptingBackend(NamedBuildTarget.WebGL,ScriptingImplementation.IL2CPP);
  PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL,ManagedStrippingLevel.Low);
  PlayerSettings.WebGL.threadsSupport=false;
  PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;
  PlayerSettings.WebGL.decompressionFallback=true;
  PlayerSettings.WebGL.dataCaching=true;
  PlayerSettings.WebGL.nameFilesAsHashes=true;
  PlayerSettings.WebGL.initialMemorySize=256;
  PlayerSettings.WebGL.maximumMemorySize=1536;
  PlayerSettings.WebGL.memoryGrowthMode=WebGLMemoryGrowthMode.Geometric;
  PlayerSettings.WebGL.exceptionSupport=WebGLExceptionSupport.FullWithoutStacktrace;
  PlayerSettings.WebGL.template="PROJECT:EZSVS";
  EditorUserBuildSettings.webGLBuildSubtarget=textures;
  PlayerSettings.runInBackground=false;PlayerSettings.defaultScreenWidth=1280;PlayerSettings.defaultScreenHeight=800;
  PlayerSettings.colorSpace=ColorSpace.Linear;
  Pipeline(true);var desktop=Pipeline(false);GraphicsSettings.defaultRenderPipeline=desktop;QualitySettings.renderPipeline=desktop;
  QualitySettings.vSyncCount=0;QualitySettings.skinWeights=SkinWeights.FourBones;
  var graphics=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);
  graphics.FindProperty("m_InstancingStripping").intValue=2;graphics.ApplyModifiedPropertiesWithoutUndo();
  const string anchorPath="Assets/Resources/Guardians/RuntimeCutout.mat";
  var anchor=AssetDatabase.LoadAssetAtPath<Material>(anchorPath);
  if(anchor==null){anchor=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(anchor,anchorPath);}
  anchor.enableInstancing=true;anchor.SetFloat("_AlphaClip",1);anchor.EnableKeyword("_ALPHATEST_ON");anchor.renderQueue=2450;EditorUtility.SetDirty(anchor);
  StreamBuild.Prepare(streams);AssetDatabase.SaveAssets();
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/Onboarding03.unity"},locationPathName=output,assetBundleManifestPath=streams+"/"+Path.GetFileName(streams)+".manifest",target=BuildTarget.WebGL,subtarget=(int)textures,options=BuildOptions.DetailedBuildReport});
  bool artifactsValid=File.Exists(output+"/index.html")&&Directory.Exists(output+"/Build")&&Directory.GetFiles(output+"/Build","*.wasm*").Length>0&&Directory.GetFiles(output+"/Build","*.loader.js").Length>0;
  Directory.CreateDirectory("Logs");File.WriteAllText("Logs/web-build-"+variant+"-summary.json",JsonUtility.ToJson(new Summary{result=report.summary.result.ToString(),variant=variant,textureFormat=textures.ToString(),artifactsValid=artifactsValid,bytes=report.summary.totalSize,seconds=report.summary.totalTime.TotalSeconds,errors=report.summary.totalErrors,warnings=report.summary.totalWarnings},true));
  if(report.summary.result!=BuildResult.Succeeded||!artifactsValid)throw new Exception("Web build failed or incomplete: "+report.summary.result+" artifactsValid="+artifactsValid);
  StreamBuild.CopyOutput(streams,output+"/StreamingAssets/EZSVS");
  Debug.Log("EZSVS_WEB_BUILD_OK variant="+variant+" bytes="+report.summary.totalSize);
 }
 [Serializable] class Summary{public string result,variant,textureFormat;public bool artifactsValid;public ulong bytes;public double seconds;public int errors,warnings;}
}
}
