using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using JinShi;
using Nanyang;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace EZSVS.LobbyHotfix {
 public static class Checks {
  [Serializable] class Item { public string name, details; public bool passed; }
  [Serializable] class Report { public bool passed; public List<Item> checks = new(); }
  public static void Validate() {
   var result = new Report();
   void Check(string name, bool passed, string details = "") {
    result.checks.Add(new Item { name = name, passed = passed, details = details });
    Debug.Log("LOBBY_GATE_CHECK " + passed + " " + name + " " + details);
   }
   var root = new GameObject("Lobby gate regression");
   try {
    JinShiKit.Font = Resources.Load<Font>("Fonts/NotoSansCJKsc-Regular");
    var context = new Ctx(root.transform);
    GuardiansRooms.Lobby(context, -32, -22, -18, -8, 4.2f, -12);
    context.k.Finish("Lobby regression geometry");
    var nav = new ExplorationNavigation(root.transform, Rect.MinMaxRect(-32, -22, -18, -8));
    var actor = new GameObject("Gate collision probe");
    actor.transform.SetParent(root.transform, false);
    var view = actor.AddComponent<ActorView>();
    view.navigation = nav;
    var capsule = actor.AddComponent<CapsuleCollider>();
    capsule.height = 1.77f;
    capsule.center = Vector3.up * .885f;
    var body = actor.AddComponent<GuardianBodyMotion>();
    typeof(GuardianBodyMotion).GetMethod("Awake", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(body, null);
    var gates = root.GetComponentsInChildren<MeshFilter>().Where(f => f.name == "JS_SpeedGate").ToArray();
    Check("three-lobby-gates", gates.Length == 3);
    for (int index = 0; index < gates.Length; index++) {
     var bounds = gates[index].GetComponent<Renderer>().bounds;
     var center = new Vector3(bounds.center.x, 0, bounds.center.z);
     foreach (float side in new[] { -1f, 1f }) {
      var at = center + Vector3.right * (bounds.extents.x * .8f * side);
      Check("cabinet-navigation-" + index + "-" + side, !nav.Clear(at));
      actor.transform.position = at + Vector3.back * 1.4f;
      var stopped = body.Move(actor.transform.position, Vector3.forward * 2.8f);
      Check("cabinet-body-" + index + "-" + side, stopped.z < center.z - .7f, stopped.ToString("F3"));
      var focus = at + new Vector3(0, .8f, -1.4f);
      var camera = GuardianCameraCollision.Resolve(focus, focus + Vector3.forward * 2.8f);
      Check("cabinet-camera-" + index + "-" + side, camera.z < center.z - .7f);
     }
     var start = center + Vector3.back * 1.4f;
     var end = center + Vector3.forward * 1.4f;
     Check("lane-navigation-" + index, nav.SegmentClear(start, end, ExplorationNavigation.Radius + .08f));
     actor.transform.position = start;
     Check("lane-forward-" + index, body.Move(start, end - start).z > center.z + 1.3f);
     actor.transform.position = end;
     Check("lane-return-" + index, body.Move(end, start - end).z < center.z - 1.3f);
    }
    foreach (float x in new[] { -27f, -19f })
     Check("fixed-barrier-" + x, !nav.SegmentClear(new Vector3(x, 0, -13.5f), new Vector3(x, 0, -10.5f)));
   } catch (Exception exception) { Check("exception", false, exception.ToString()); }
   finally { Object.DestroyImmediate(root); }
   result.passed = result.checks.All(c => c.passed);
   Directory.CreateDirectory("Logs");
   File.WriteAllText("Logs/lobby-gate-checks.json", JsonUtility.ToJson(result, true));
   Debug.Log("LOBBY_GATE_CHECK_COMPLETE " + result.passed + " checks=" + result.checks.Count);
   EditorApplication.Exit(result.passed ? 0 : 2);
  }
 }
}

