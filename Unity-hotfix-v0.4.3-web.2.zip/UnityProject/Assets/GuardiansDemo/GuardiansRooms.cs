using System.Collections.Generic;
using UnityEngine;
using M=JinShi.DCModules;
namespace JinShi { public static class GuardiansRooms {
        public static void ToolRoom(Ctx c,float x0,float z0,float x1,float z1,float h,Vector3[] west=null,Vector3[] north=null)
        {
            M.Room(c,x0,z0,x1,z1,h,c.epoxy,c.wall,c.ceiling,west:west,north:north,south:new[]{M.Gap(2,2,2.3f)});
            c.Place("JS_Shelving",x0+1.4f,z1-.5f,180);c.Place("JS_Shelving",x0+3.4f,z1-.5f,180);
            c.Place("JS_ToolCabinet",x1-.5f,z0+1.4f,-90);c.Place("JS_ServerLift",x1-.8f,z1-1.4f,-90);c.Place("JS_Ladder",x0+.6f,z0+.6f,0);
            // workbench in the corner with the old radio on its charger
            c.k.Box(new Vector3(x1-2.2f,.85f,z0+.2f),new Vector3(x1-.2f,.9f,z0+.9f),JinShiKit.Lit("#8A6A4C",.35f),false);
            foreach(float x in new[]{x1-2.1f,x1-.3f})c.k.Box(new Vector3(x-.03f,0,z0+.25f),new Vector3(x+.03f,.85f,z0+.85f),c.steel,false);
            c.k.Solid(new Vector3(x1-1.2f,.45f,z0+.55f),new Vector3(2,.9f,.7f));
            var radio=c.Place("JS_Walkie_JS2005",x1-.6f,z0+.5f,200,.9f,"JS-2005-0001");
            c.Info(radio,"JS-2005-0001","一台一直插在充电座上的老对讲机。资产系统 2005 年登记，没人敢拔。\n背面贴着手写标签：“精诚所至，金石为开。给下一个值班的人。”\n电池已经换到第三代。",1.6f);
            c.Sign("工具间  TOOL ROOM",new Vector3(x0+.12f,2.3f,(z0+z1)/2+1.2f),Vector3.right,.06f);
            JinShiKit.PointLight(c.root,new Vector3((x0+x1)/2,h-.3f,(z0+z1)/2),7,1.4f);c.Place("JS_LEDPanel",(x0+x1)/2,(z0+z1)/2,0,h-.01f);
        }
        public static void Lobby(Ctx c,float x0,float z0,float x1,float z1,float h,float gateZ)
        {
            M.Room(c,x0,z0,x1,z1,h,JinShiKit.Lit("#B9B4AA",.6f),c.wall,c.ceiling,south:new[]{M.Gap((x1-x0)/2,3.2f,2.8f)},north:new[]{M.Gap((x1-x0)/2,2.4f,2.8f)});
            var desk=c.Place("JS_Reception",x1-4.5f,gateZ-3.2f,180);
            c.Info(desk,"保安前台","访客登记、证件核验、临时卡发放。访客全程要有人陪同（红线 1）；尾随进门（红线 2）在这里就要拦下。");
            const float gateWidth = 1.4f;
            float gateStart = (x0 + x1) / 2 + .5f;
            for (int i = 0; i < 3; i++)
                LobbyGate(c, new Vector3(gateStart + gateWidth * (i + .5f), 0, gateZ), gateWidth);
            c.k.Box(new Vector3(x0,0,gateZ-.7f),new Vector3((x0+x1)/2+.5f,1.1f,gateZ+.7f),c.glass,true);
            c.k.Box(new Vector3(gateStart + 3 * gateWidth,0,gateZ-.7f),new Vector3(x1,1.1f,gateZ+.7f),c.glass,true);
            c.Place("JS_Sofa",x1-1.3f,z0+3.5f,-90);c.Place("JS_Plant",x0+6,z0+1);c.Place("JS_Plant",x1-1,z0+1);
            // reception feature wall: walnut panel with a warm backlight slot, brushed-gold name, quiet motto
            float cx=(x0+x1)/2,wall=z1-.1f;
            c.k.Box(new Vector3(cx-3.6f,.95f,wall-.08f),new Vector3(cx+3.6f,3.25f,wall),JinShiKit.Lit("#8A6A4C",.45f),true);
            c.k.Box(new Vector3(cx-3.7f,.9f,wall-.1f),new Vector3(cx+3.7f,.95f,wall),JinShiKit.Lit("#1C1D1F",.6f,.4f),false);
            c.k.Box(new Vector3(cx-3.5f,3.27f,wall-.06f),new Vector3(cx+3.5f,3.3f,wall),JinShiKit.Lit("#FFD9A0",.5f,0,2.2f),false);
            JinShiKit.PointLight(c.root,new Vector3(cx,3.0f,wall-.6f),4.5f,.9f,new Color(1,.85f,.62f));
            c.Sign("金石易服  ·  狮城一号石殿",new Vector3(cx,2.45f,wall-.08f),Vector3.back,.075f,new Color(.84f,.68f,.36f));
            c.Sign("精诚 · 至简 · 卓越 · 尊享",new Vector3(cx,2.0f,wall-.08f),Vector3.back,.04f,new Color(.86f,.84f,.8f));
            M.Lights(c,x0,z0,x1,z1,h-.02f,2.4f,2.4f,true,2,1.5f);
        }
        static void LobbyGate(Ctx c, Vector3 at, float width)
        {
            var root = new GameObject("大堂闸机 · 开放通道").transform;
            root.SetParent(c.root, false);
            root.localPosition = at;
            root.localScale = new Vector3(width, 1, 1);
            var visual = JinShiKit.Place("JS_SpeedGate", root, Vector3.zero);
            // The imported kit is one joined mesh. Replace its whole-model box
            // with cabinet footprints and move the closed glass into open leaves.
            JinShiKit.Passable(visual);
            var glass = JinShiKit.Map("JS_Glass");
            foreach (var filter in visual.GetComponentsInChildren<MeshFilter>())
            {
                var renderer = filter.GetComponent<MeshRenderer>();
                var source = filter.sharedMesh;
                var materials = new List<Material>();
                var triangles = new List<int[]>();
                for (int submesh = 0; submesh < source.subMeshCount; submesh++)
                {
                    if (renderer.sharedMaterials[submesh] == glass) continue;
                    materials.Add(renderer.sharedMaterials[submesh]);
                    triangles.Add(source.GetTriangles(submesh));
                }
                var mesh = Object.Instantiate(source);
                mesh.name = "Lobby gate cabinets";
                mesh.subMeshCount = triangles.Count;
                for (int submesh = 0; submesh < triangles.Count; submesh++)
                    mesh.SetTriangles(triangles[submesh], submesh);
                mesh.RecalculateBounds();
                filter.sharedMesh = mesh;
                renderer.sharedMaterials = materials.ToArray();
                GuardianRoomLifetime.Own(c.root, mesh);
            }
            foreach (float side in new[] { -1f, 1f })
            {
                var cabinet = new GameObject("闸机机身碰撞体");
                cabinet.transform.SetParent(root, false);
                var collider = cabinet.AddComponent<BoxCollider>();
                collider.center = new Vector3(side * .4f, .5125f, 0);
                collider.size = new Vector3(.2f, 1.025f, 1.4f);
                var leaf = GameObject.CreatePrimitive(PrimitiveType.Cube);
                leaf.name = "闸机玻璃 · 已打开";
                leaf.transform.SetParent(root, false);
                leaf.transform.localPosition = new Vector3(side * .3f, .675f, .14f);
                leaf.transform.localScale = new Vector3(.04f / width, .65f, .28f);
                leaf.GetComponent<Renderer>().sharedMaterial = glass;
            }
        }
}}
